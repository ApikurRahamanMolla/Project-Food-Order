package com.example.foodorderback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodOrderBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodOrderBackApplication.class, args);
	}

}
